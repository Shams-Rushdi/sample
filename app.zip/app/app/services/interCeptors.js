
app.factory("interCeptor",function($location)
{return{
    'request':function(confiq){
        console.log("Intercepter");
        config.headers.Authorization = localStorage.getItem('token')
        return confiq;
    },
    'responseError':function(rejection)
    {
        
    }
}

});