app.controller("addmembers",function($scope){
    $scope.addmembers = function()
    {
        $http.post("https://localhost:44350/api/users/create", $scope.data)
        .then (function(resp)
        {

        },function(err)
        {

        });
    };
});
