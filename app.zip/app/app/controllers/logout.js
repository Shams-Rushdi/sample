app.controller("logout",function($){
    //localStorage.removeItem('token');
    $http.get("https://localhost:44368/api/logout")
    .then(function(resp){
        localStorage.removeItem("token");
    },function(err){
        console.log(err);
    });
});

