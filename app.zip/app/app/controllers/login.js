app.controller("login",function($scope,$http,$window){
    var link1 = "https://" + $window.location.host + "../views/pages/addmembers";
    var app = angular.module('addmembers', []);
    var s = 2;
    $scope.login = function()
    {
        $http.post("https://localhost:44350/api/login", $scope.data)
        .then (function(resp)
        {
            console.log(resp.data);
            
            //$window.location=link1;
            //window.location.href = 'views/pages/addmembers';
            //$location.path("/addmembers" );
            //$location.path("/" );
            //templateUrl : "views/pages/addmembers.html";
            window.location.href = '#!addmembers';

        },function(err)
        {
            //window.location.href = '#!addmembers';
            alert('failed');
            console.log(resp.data);
        });
    };
});
