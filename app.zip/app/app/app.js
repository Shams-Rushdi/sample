var app = angular.module("myApp", ["ngRoute"]);
app.config(["$routeProvider","$locationProvider",function($routeProvider,$locationProvider) {

    $routeProvider
    .when("/", {
        templateUrl : "views/pages/demopage.html"
    })
    .when("/demo", {
        templateUrl : "views/pages/demopage.html",
        controller: 'demo'
    })
    .when("/demo2", {
        templateUrl : "views/pages/demo2.html",
          controller: 'demo2'
    })
    .when("/products", {
        templateUrl : "views/pages/products.html",
        controller: 'products'
    })
    .when("/addmembers", {
        templateUrl : "views/pages/addmembers.html",
        controller: 'addmembers'
    })
    .when("/login", {
        templateUrl : "views/pages/login.html",
        controller: 'login'
    })
    .when("/logout", {
        templateUrl : "views/pages/login.html",
        controller: 'logout'
    })
    .otherwise({
        redirectTo:"/"
    });
      //$locationProvider.html5Mode(true);
      //$locationProvider.hashPrefix('');
      //if(window.history && window.history.pushState){
      //$locationProvider.html5Mode(true);
  //}

}]);

//app.controller('addmembers', function($scope) {  
    // create a message to display in our view    
//    $scope.HomeMessage = 'Home Controller Called !!!';  
//});  
  
//app.controller('addmembers', function($scope) {  
  //  $scope.AboutMessage = 'About Controller Called !!!';  
//});  
  
//app.controller('contactController', function($scope) {  
//    $scope.ContactMessage = 'Contact Controller Called !!!';  
//});  
